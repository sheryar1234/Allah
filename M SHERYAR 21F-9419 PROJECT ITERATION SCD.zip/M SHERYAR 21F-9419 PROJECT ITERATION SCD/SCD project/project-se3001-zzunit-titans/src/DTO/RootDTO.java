package DTO;

public class RootDTO {

}
