package DTO;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import DAL.PoemDAL;

public class PoemDTO {

	public PoemDTO() {
		// TODO Auto-generated constructor stub
	}
	public void importPoemsFromTxt() throws IOException {
	    String filePath = "C:\\Users\\ZOHAIB\\Downloads\\Poem.txt";
	    
	    try (BufferedReader fileReading = new BufferedReader(
	            new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {

	        String line;
	        boolean skip = false;
	        int start, end;
	        String title = "";
	        StringBuilder poemData = new StringBuilder();

	        while ((line = fileReading.readLine()) != null) {

	            if (skip) {
	                if (line.contains("==========")) {
	                    skip = false;
	                }
	                continue;
	            }

	            if (line.contains("_________")) {
	                skip = true;
	                if (!title.isEmpty() && poemData.length() > 0) {
	                    new PoemDAL().importPoemFromTxt(title, poemData.toString());
	                    poemData = new StringBuilder();
	                }
	                continue;
	            }

	            if (line.startsWith("[")) {
	                start = line.indexOf('[') + 1;
	                end = line.indexOf(']');
	                title = line.substring(start, end);
	            } else if (line.startsWith("(")) {
	                start = line.indexOf('(') + 1;
	                end = line.indexOf(')');
	                
	                if (start != 0 && end != -1) {
	                    poemData.append(line.substring(start, end)).append("\n");
	                }
	            }
	        }
	    }
	}


}
