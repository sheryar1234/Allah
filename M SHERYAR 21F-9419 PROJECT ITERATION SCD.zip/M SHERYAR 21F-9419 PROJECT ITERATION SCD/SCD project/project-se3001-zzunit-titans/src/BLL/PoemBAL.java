package BLL;


import DAL.PoemDAL;

public class PoemBAL {
	private PoemDAL PoemManager;

	public PoemBAL() {
		this.PoemManager = new PoemDAL();
	}

	public void addPoem(String bookTitle, String bookID, String poemName, String poemData) {
		PoemManager.addPoem(bookTitle, bookID, poemName, poemData);
	}

	public void deletePoem(String poemName) {
		PoemManager.deletePoem(poemName);
	}

	public void updatePoem(String bookTitle, String bookID, String poemName, String poemData) {
		((PoemDAL) PoemManager).updatePoem(bookTitle, bookID, poemName, poemData);
	}
	public void importPoemFromTxt(String poemName, String poemData) {
		((PoemDAL) PoemManager).importPoemFromTxt(poemName, poemData);
	}
	public String getPoemData(String poemName) {
		return PoemManager.getPoemData(poemName);
	}
	
}
