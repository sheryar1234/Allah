package DAL;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PoemDAL implements PoemAdder, PoemDeleter, PoemUpdater, PoemReader {
    String filePath = "C:\\Users\\f219419\\Downloads\\Poem.txt";

    private static final String URL = "jdbc:mysql://localhost:3306/Poem";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";


    public void importPoemFromTxt(String poemName, String poemData) {
        String query = "INSERT IGNORE INTO Poemdata (poemName, poemData) VALUES (?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setString(1, poemName);
            preparedStatement.setString(2, poemData);
            preparedStatement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
