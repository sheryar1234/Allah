package PL;

import javax.swing.*;

import DAL.PoemDAL;
import DTO.PoemDTO;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PoemPL {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            JFrame frame = new JFrame("Poem Manager");
            frame.setSize(700, 500);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);

            JPanel mainPanel = new JPanel(new GridLayout(3, 1, 10, 10));
            mainPanel.setBackground(new Color(60, 63, 65));
            mainPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

            JButton importPoemButton = createStyledButton("Import Poems");
            importPoemButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    PoemDTO dao = new PoemDTO();
                    try {
                        dao.importPoemsFromTxt();
                        JOptionPane.showMessageDialog(null, "Poems Imported Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error reading from the Poem.txt.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            mainPanel.add(importPoemButton);

            JButton addPoemButton = createStyledButton("Add Poem");
            addPoemButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Implementation of the add poem functionality
                }
            });
            mainPanel.add(addPoemButton);

            JButton deletePoemButton = createStyledButton("Delete Poem");
            deletePoemButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Implementation of the delete poem functionality
                }
            });
            mainPanel.add(deletePoemButton);

            JButton showPoemButton = createStyledButton("Show Poem");
            showPoemButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Implementation of the show poem functionality
                }
            });
            mainPanel.add(showPoemButton);

            frame.add(mainPanel);
            frame.setVisible(true);
        });
    }

    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(66, 133, 244));
        button.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(58, 115, 217));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(66, 133, 244));
            }
        });
        return button;
    }
}
