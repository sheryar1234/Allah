import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("Poem Manager");
                frame.setSize(400, 300);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                JButton addPoemButton = new JButton("Add Poem");
                JButton deletePoemButton = new JButton("Delete Poem");
                JButton updatePoemButton = new JButton("Update Poem");
                JButton showPoemButton = new JButton("Show Poem");

                PoemManager poemManager = new PoemManager();

                addPoemButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame addFrame = new JFrame("Add Poem");
                        addFrame.setSize(400, 300);

                        JPanel panel = new JPanel();
                        panel.setLayout(new GridLayout(0, 2, 5, 5));

                        JTextField bookTitleField = new JTextField(10);
                        JTextField bookIDField = new JTextField(10);
                        JTextField poemNameField = new JTextField(10);

                        panel.add(new JLabel("Book Title"));
                        panel.add(bookTitleField);
                        panel.add(new JLabel("Book ID"));
                        panel.add(bookIDField);
                        panel.add(new JLabel("Poem Name"));
                        panel.add(poemNameField);

                        List<JTextField> lineFields = new ArrayList<>();

                        JButton addLineButton = new JButton("+");
                        panel.add(addLineButton);

                        addLineButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                JTextField newLineField1 = new JTextField(10);
                                JTextField newLineField2 = new JTextField(10);
                                panel.add(newLineField1);
                                panel.add(newLineField2);
                                lineFields.add(newLineField1);
                                lineFields.add(newLineField2);
                                addFrame.pack();
                            }
                        });

                        JButton saveButton = new JButton("Save");
                        panel.add(saveButton);

                        saveButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                String bookTitle = bookTitleField.getText();
                                String bookID = bookIDField.getText();
                                String poemName = poemNameField.getText();

                                StringBuilder poemData = new StringBuilder();
                                for (int i = 0; i < lineFields.size(); i += 2) {
                                    String line1 = lineFields.get(i).getText();
                                    String line2 = lineFields.get(i + 1).getText();
                                    poemData.append(line1).append("\n").append(line2).append("\n");
                                }

                                try {
                                    poem poemManager = new poem();
                                    poemManager.addPoem("C:\\Users\\M Shehriyar\\Downloads\\Poem.txt", bookTitle, bookID, poemName, poemData.toString());
                                    JOptionPane.showMessageDialog(null, "Poem Saved Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                                } catch (IOException ex) {
                                    JOptionPane.showMessageDialog(null, "Error writing to the poem file.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        });


                        addFrame.add(panel);
                        addFrame.setVisible(true);
                    }
                });

                deletePoemButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame deleteFrame = new JFrame("Delete Poem");
                        deleteFrame.setSize(400, 300);

                        JPanel panel = new JPanel();
                        panel.setLayout(new GridLayout(0, 2, 10, 10));

                        JTextField bookTitleField = new JTextField(10);
                        JTextField bookIDField = new JTextField(10);
                        JTextField poemNameField = new JTextField(10);

                        panel.add(new JLabel("Book Title"));
                        panel.add(bookTitleField);
                        panel.add(new JLabel("Book ID"));
                        panel.add(bookIDField);
                        panel.add(new JLabel("Poem Name"));
                        panel.add(poemNameField);

                        JButton deleteButton = new JButton("Delete");
                        panel.add(deleteButton);

                        deleteButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                String poemName = poemNameField.getText();
                                try {
                                    poem poemManager = new poem(); // Create an instance of the poem class
                                    poemManager.deletePoem("C:\\Users\\M Shehriyar\\Downloads\\Poem.txt", poemName);
                                    JOptionPane.showMessageDialog(null, "Poem Deleted Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                                } catch (IOException ex) {
                                    JOptionPane.showMessageDialog(null, "Error deleting the poem from the file.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        });


                        deleteFrame.add(panel);
                        deleteFrame.setVisible(true);
                    }
                });
                updatePoemButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame updateFrame = new JFrame("Update Poem");
                        updateFrame.setSize(400, 300);

                        JPanel panel = new JPanel();
                        panel.setLayout(new GridLayout(0, 2, 10, 10));

                        JTextField bookTitleField = new JTextField(10);
                        JTextField bookIDField = new JTextField(10);
                        JTextField poemNameField = new JTextField(10);

                        panel.add(new JLabel("Book Title"));
                        panel.add(bookTitleField);
                        panel.add(new JLabel("Book ID"));
                        panel.add(bookIDField);
                        panel.add(new JLabel("Poem Name"));
                        panel.add(poemNameField);

                        JButton searchButton = new JButton("Search");
                        panel.add(searchButton);

                        JTextField misra1Field = new JTextField(10);
                        JTextField misra2Field = new JTextField(10);

                        searchButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                // Logic to load poem and update text fields
                                // ...
                            }
                        });

                        panel.add(misra1Field);
                        panel.add(misra2Field);

                        JButton updateButton = new JButton("Update");
                        panel.add(updateButton);

                        updateButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                    
                                JOptionPane.showMessageDialog(null, "Poem Updated Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                            }
                        });

                        updateFrame.add(panel);
                        updateFrame.setVisible(true);
                    }
                });

          
                showPoemButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame showFrame = new JFrame("Show Poem");
                        showFrame.setSize(400, 300);

                        JPanel panel = new JPanel();
                        panel.setLayout(new GridLayout(0, 2, 10, 10));

                        JTextField bookTitleField = new JTextField(10);
                        JTextField bookIDField = new JTextField(10);
                        JTextField poemNameField = new JTextField(10);

                        panel.add(new JLabel("Book Title"));
                        panel.add(bookTitleField);
                        panel.add(new JLabel("Book ID"));
                        panel.add(bookIDField);
                        panel.add(new JLabel("Poem Name"));
                        panel.add(poemNameField);

                        JButton showButton = new JButton("Show");
                        panel.add(showButton);

                        poem Poem = new poem(); // Creating an instance of Poem class

                        showButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                try {
                                    String poemTitle = poemNameField.getText();
                                    List<String> verses = Poem.getPoemVerses("C:\\Users\\M Shehriyar\\Downloads\\Poem.txt", poemTitle);
                                    
                                    JPanel versesPanel = new JPanel(new GridLayout(verses.size(), 1));
                                    
                                    for (String verse : verses) {
                                        JTextField verseField = new JTextField(verse);
                                        verseField.setEditable(false);
                                        versesPanel.add(verseField);
                                    }
                                    
                                    if (!verses.isEmpty()) {
                                        JOptionPane.showMessageDialog(null, new JScrollPane(versesPanel), "Poem", JOptionPane.PLAIN_MESSAGE);
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Poem with the given title not found.", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                } catch (IOException ex) {
                                    JOptionPane.showMessageDialog(null, "Error reading the poem file.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        });


                        showFrame.add(panel);
                        showFrame.setVisible(true);
                    }
                });

                JPanel panel = new JPanel();
                panel.add(addPoemButton);
                panel.add(deletePoemButton);
                panel.add(updatePoemButton);
                panel.add(showPoemButton);

                frame.add(panel);
                frame.setVisible(true);
            }
        });
    }
}
