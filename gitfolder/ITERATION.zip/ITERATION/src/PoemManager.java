public class PoemManager {
    private PoemDataAccess poemDataAccess;

    public PoemManager() {
        this.poemDataAccess = new PoemDataAccess();
    }


    public void addPoem(String bookTitle, String bookID, String poemName, String poemData) {
        poemDataAccess.addPoem(bookTitle, bookID, poemName, poemData);
    }
    public void deletePoem( String poemName,Boolean poemDeleted) {
        // Add logic for deleting a poem
        poemDataAccess.deletePoem( poemName,poemDeleted);
    }

  //  public void updatePoem(String bookTitle, String bookID, String poemName) {
        // Add logic for updating a poem
    //    poemDataAccess.updatePoem(bookTitle, bookID, poemName);
  //  }

    public String showPoem() {
        // Add logic for displaying poems
        return poemDataAccess.showPoem();
    }
}
