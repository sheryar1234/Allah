import java.sql.*;

public class PoemDataAccess {
    private static final String URL = "jdbc:mysql://localhost:3306/poems_db";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public void addPoem(String bookTitle, String bookID, String poemName, String poemData) {
        String query = "INSERT INTO poems (bookTitle, bookID, poemName, poemData) VALUES (?, ?, ?, ?)";
        
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setString(1, bookTitle);
            preparedStatement.setString(2, bookID);
            preparedStatement.setString(3, poemName);
            preparedStatement.setString(4, poemData);

            preparedStatement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePoem(String poemName) {
        String query = "DELETE FROM poems WHERE poemName = ?";
        
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setString(1, poemName);
            preparedStatement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getPoemData(String poemName) {
        String query = "SELECT poemData FROM poems WHERE poemName = ?";
        
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
             
            preparedStatement.setString(1, poemName);
            ResultSet rs = preparedStatement.executeQuery();
            
            if(rs.next()) {
                return rs.getString("poemData");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
