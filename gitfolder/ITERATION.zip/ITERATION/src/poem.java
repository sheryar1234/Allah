import java.util.ArrayList;
import java.util.List;

public class poem {

    private PoemDataAccess poemDataAccess;

    public poem() {
        this.poemDataAccess = new PoemDataAccess();
    }

    public List<String> getPoemVerses(String poemName) {
        List<String> verses = new ArrayList<>();
        
        String poemData = poemDataAccess.getPoemData(poemName);
        
        if(poemData != null) {
            String[] lines = poemData.split("\n");
            for(String line: lines) {
                verses.add(line);
            }
        }
        return verses;
    }

    public void addPoem(String bookTitle, String bookID, String poemName, String poemData) {
        poemDataAccess.addPoem(bookTitle, bookID, poemName, poemData);
    }

    public void deletePoem(String poemName) {
        poemDataAccess.deletePoem(poemName);
    }
}
